1- Pour lancer le site, executer "Index.html". Il faut ouvrir le fichier de préférence avec chrome ou firefox, en deuxième choix microsoft edge et en dernier choix internet explorer.

2- Une connection internet n'est pas requise pour lancer le site, mais est recommandé pour un affichage complet du site

3- Une résolution d'écran de 1280*720 (HD) est recommandée pour la bonne lisibilité du site, bien qu'une résolution de 1920*1080(FULL HD) ne pose aucun soucis. En dessous, le contenu risque d'être partiellement découpé.

4- Le schéma du robot utilise un format propriétaire (.fzz) qui s'ouvre avec le logiciel Fritzing. Néanmoins, une photo du schéma est disponible sous la page conception.

5- Pour savoir à quoi correspondent les opérandes des formules mathématiques, il suffit de glisser le pointeur de la souris dessus.